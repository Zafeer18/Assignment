package com.QAAssignment.Quantra;

public class Locators {

	//Locators
			public static String LoginButton = "//span[text()=\"Login\"]/../..";
			public static String emailField = "//input[@type=\"email\"]";
			public static String pass = "//input[@type=\"password\"]";
			public static String submit = "//button[@type=\"submit\"]";
			
			public static String checkLogin = "//div[@class=\"profile-pic-initials\"]";
			
			public static String BrowseCourses = "//a[@href=\"/courses\"]";
			public static String Course = "//span[text()=\"Sentiment Analysis in Trading\"]/..";
			
			public static String EnrollNow = "//span[contains(text(),\"Enroll Now\")]/../..";
			public static String CourseName = "//div[@class=\"course-detail__left-view\"]/h1";
			public static String CoursePrice = "//div[text()=\"Price\"]/following-sibling::div/span[2]/span";
			
			
			public static String CartItem = "//div[@class=\"cart-item\"]";
			public static String CartNumber = "//span[@class=\"cart-count\"]";
			public static String BaseAmount = "//div[text()=\"Base Amount\"]/following-sibling::div";
			public static String AmountPayable = "//h5[text()=\"Amount Payable\"]/../following-sibling::div/h5";
			
			public static String ViewDetails = "//a[text()=\"View Details\"][1]";
			public static String RemoveCartItem = "//a[text()=\"Remove\"][1]";
			
			public static String alertText = "//div[contains(@class,\"toasted-container\")]/div";
			
			public static String ApplyCouponButton = "//div[@class=\"coupon-btn-unit\"]/button";
			
			public static String CouponCodeInput = "//input[contains(@placeholder,\"Type coupon\")]";
			public static String ApplyInsideModal = "//div[@class=\"coupon-form__button\"]/button";
			public static String CouponAlert = "//div[@class=\"coupon-alert-box\"]/div/span";
			public static String CloseModal = "//button[@class=\"close\"]";
			
			public static String Logout = "//ul[@class=\"avatar-menu\"]/li[contains(@class,\"logout\")]/a";
	
}
