package com.QAAssignment.Quantra;

public class Section3 {

	public static void main(String[] args) {
		
		int count = 0;
		
		for (int i=1;i<1000;i++) {
			if(i%3==0 || i%5==0) {
				count = count+i;
			}
		}
		
		System.out.println("The sum of all the number which are multiples of 3 and 5 below 1000 is : " + count);

	}

}
