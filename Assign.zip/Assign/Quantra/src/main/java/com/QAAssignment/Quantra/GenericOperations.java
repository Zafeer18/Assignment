package com.QAAssignment.Quantra;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Base64;


import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class GenericOperations {
	
	private static String url = "https://quantra.quantinsti.com/";
	private static String username = "zafeer@live.com";
	private static String CouponCode = "ABC";

	public static String getPass() {
		byte[] decodedBytes = Base64.getDecoder().decode("UXVhbnRJbnN0aVBhc3N3b3Jk");
		return new String(decodedBytes);
	}
	
	public static String getUrl() {
		return url;
	}

	public static String getUsername() {
		return username;
	}

	public static String getCouponCode() {
		return CouponCode;
	}
	
	public static String capture(WebDriver driver) throws IOException {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File(System.getProperty("user.dir") + "\\Extent_Report\\SS\\" + System.currentTimeMillis()
		+ ".png");
		String errflpath = Dest.getAbsolutePath();
		
		Files.copy(scrFile.toPath(), Dest.toPath(),
                StandardCopyOption.REPLACE_EXISTING);

		return errflpath;
		}

	
}
