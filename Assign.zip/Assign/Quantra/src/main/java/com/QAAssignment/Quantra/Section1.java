package com.QAAssignment.Quantra;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import org.testng.annotations.BeforeTest;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class Section1 {

	static WebDriver oDriver = null;
	static ExtentTest test;
	static ExtentReports report;

	@Test
	public void Quantra_Test() throws InterruptedException, IOException {

		WebDriverWait oWait = new WebDriverWait(oDriver, 15);

		oDriver.get(GenericOperations.getUrl());

		oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.LoginButton)));

		if(oDriver.getTitle().contains("Quantra")) {
			test.log(LogStatus.INFO, test.addScreenCapture(GenericOperations.capture(oDriver))+"Quantra URL launched successfully.");
		}
		else {
			test.log(LogStatus.FAIL, test.addScreenCapture(GenericOperations.capture(oDriver))+"Desired URL was not launched successfully after 15 seconds.");
		}


		oDriver.findElement(By.xpath(Locators.LoginButton)).click();

		oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.submit)));

		oDriver.findElement(By.xpath(Locators.emailField)).sendKeys(GenericOperations.getUsername());
		oDriver.findElement(By.xpath(Locators.pass)).sendKeys(GenericOperations.getPass());
		oDriver.findElement(By.xpath(Locators.submit)).click();


		try{
			oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.checkLogin)));
			test.log(LogStatus.INFO,test.addScreenCapture(GenericOperations.capture(oDriver))+ "Login Successful !!");
		}catch(Exception e) {
			test.log(LogStatus.FAIL, test.addScreenCapture(GenericOperations.capture(oDriver))+"Login Failed !!");
		}

		oDriver.findElement(By.xpath(Locators.BrowseCourses)).click();
		oDriver.findElement(By.xpath(Locators.Course)).click();

		oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.EnrollNow)));

		String CourseN = oDriver.findElement(By.xpath(Locators.CourseName)).getText();
		String CourseP = oDriver.findElement(By.xpath(Locators.CoursePrice)).getText();

		test.log(LogStatus.PASS, test.addScreenCapture(GenericOperations.capture(oDriver))+"The name of the course is : \"" + CourseN+"\"");
		test.log(LogStatus.PASS,"The price of the course is : \"" + CourseP+"\"");

		test.log(LogStatus.INFO, "Enrolling now !");

		oDriver.findElement(By.xpath(Locators.EnrollNow)).click();


		try{
			oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.CartItem)));
			test.log(LogStatus.INFO, test.addScreenCapture(GenericOperations.capture(oDriver))+"Cart Loaded.");
		}catch(Exception e) {
			test.log(LogStatus.FAIL, test.addScreenCapture(GenericOperations.capture(oDriver))+"Error in loading cart.");
		}


		List <WebElement> CartItems = oDriver.findElements(By.xpath(Locators.CartItem));

		test.log(LogStatus.PASS, test.addScreenCapture(GenericOperations.capture(oDriver))+"Number of courses added in Cart : " + CartItems.size());
		String NumberOnCartIcon = oDriver.findElement(By.xpath(Locators.CartNumber)).getText();
		test.log(LogStatus.PASS,"Number displayed in the cart icon : " + NumberOnCartIcon);
		
		if(CartItems.size()==Integer.parseInt(NumberOnCartIcon)) {
			test.log(LogStatus.PASS,"Number of items in the cart list and number of items displayed on the cart icon are equal !");
		}


		String base = oDriver.findElement(By.xpath(Locators.BaseAmount)).getText();
		String payable = oDriver.findElement(By.xpath(Locators.AmountPayable)).getText();

		test.log(LogStatus.PASS, test.addScreenCapture(GenericOperations.capture(oDriver))+"Base Price is : " + base);
		test.log(LogStatus.PASS, "Amount Payable is : " + payable);

		String currentHandle = oDriver.getWindowHandle();

		oDriver.findElement(By.xpath(Locators.ViewDetails)).click();

		Thread.sleep(2000);

		test.log(LogStatus.INFO, "Clicked on View Details and New Window opened !");


		Set<String> handles = oDriver.getWindowHandles();

		for (String actual: handles) {
			if (!actual.equalsIgnoreCase(currentHandle)) {               
				oDriver.switchTo().window(actual);               
			}
		}

		test.log(LogStatus.INFO, test.addScreenCapture(GenericOperations.capture(oDriver))+"Switch to new Window with Title \"" + oDriver.getTitle() +"\" done !");

		oDriver.close();

		test.log(LogStatus.INFO,"New Window Closed !");

		oDriver.switchTo().window(currentHandle);

		test.log(LogStatus.INFO, test.addScreenCapture(GenericOperations.capture(oDriver))+"Switched back to Original Window ! ");

		oDriver.findElement(By.xpath(Locators.RemoveCartItem)).click();

		test.log(LogStatus.INFO, test.addScreenCapture(GenericOperations.capture(oDriver))+"One item removed.");

		try{

			oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.alertText)));
			String AlertText = oDriver.findElement(By.xpath(Locators.alertText)).getText();
			test.log(LogStatus.PASS, test.addScreenCapture(GenericOperations.capture(oDriver))+"The alert text reads - " + AlertText.replaceAll("UNDO", "").replaceAll("\n", ""));

		}catch(Exception e) {
			test.log(LogStatus.FAIL, test.addScreenCapture(GenericOperations.capture(oDriver))+"Alert after removal not found");
		}


		oDriver.findElement(By.xpath(Locators.ApplyCouponButton)).click();

		try{
			oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.CouponCodeInput)));
			test.log(LogStatus.INFO, test.addScreenCapture(GenericOperations.capture(oDriver))+"Coupon Modal Loaded.");
		}catch(Exception e) {
			test.log(LogStatus.FAIL, test.addScreenCapture(GenericOperations.capture(oDriver))+"Error in loading coupon modal.");
		}


		oDriver.findElement(By.xpath(Locators.CouponCodeInput)).sendKeys(GenericOperations.getCouponCode());
		oDriver.findElement(By.xpath(Locators.ApplyInsideModal)).click();

		Thread.sleep(1500);

		String couponAlert = oDriver.findElement(By.xpath(Locators.CouponAlert)).getText();

		test.log(LogStatus.PASS, test.addScreenCapture(GenericOperations.capture(oDriver))+"Alert after applying Coupon : " + couponAlert);

		oDriver.findElement(By.xpath(Locators.CloseModal)).click();

		oDriver.findElement(By.xpath(Locators.checkLogin)).click();

		oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(Locators.Logout)));
		oDriver.findElement(By.xpath(Locators.Logout)).click();

		test.log(LogStatus.PASS, test.addScreenCapture(GenericOperations.capture(oDriver))+"Logged out of application !!");
	}

	@BeforeTest
	public void beforeTest() {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\DriverExe\\chromedriver.exe");

		ChromeOptions options = new ChromeOptions();

		options.addArguments("start-maximized"); 
		options.addArguments("enable-automation"); 

		options.addArguments("--no-sandbox"); 
		options.addArguments("--disable-infobars"); 
		options.addArguments("--disable-dev-shm-usage"); 
		options.addArguments("--disable-browser-side-navigation"); 
		options.addArguments("--disable-gpu"); 

		oDriver =  new ChromeDriver(options);
		oDriver.manage().window().maximize();

		report = new ExtentReports(System.getProperty("user.dir")+"\\Extent_Report\\Extent_Reports.html");
		test = report.startTest("Section 1");

	}

	@AfterTest
	public void afterTest() {
		
		report.endTest(test);
		report.flush();

		oDriver.close();
		oDriver.quit();
	}

}
